class CalendarController < ApplicationController
  def make
    if params[:date]
      begin
        indicate = params[:date].split("-")
        session[:date] = Date.new(indicate[0].to_i,indicate[1].to_i,indicate[2].to_i)
      rescue
        flash[:notice] = "Invalid #{params[:date]}"
      end
    end
    unless session[:date]
      session[:date] = Date.today
    end
    @date = session[:date]
  end
end
