require 'test_helper'

class CalendarControllerTest < ActionDispatch::IntegrationTest
  test "should get make" do
    get calendar_make_url
    assert_response :success
  end

end
